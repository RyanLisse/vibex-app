import { describe, expect, it } from "vitest";

describe("Inngest Actions", () => {
	it("should render without errors", () => {
		expect(true).toBe(true);
	});
});
