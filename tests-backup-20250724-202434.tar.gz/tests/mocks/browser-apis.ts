// Browser APIs Mocking Utilities
// Comprehensive mocking for browser-specific APIs
