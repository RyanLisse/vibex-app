// VibeKit SDK Mocking Utilities
// Comprehensive mocking for VibeKit SDK operations
