// Enhanced Next.js Router Mocking Utilities
// Comprehensive router mocking beyond basic setup
