// GitHub Authentication Mocking Utilities
// Comprehensive mocking for GitHub OAuth and API operations
