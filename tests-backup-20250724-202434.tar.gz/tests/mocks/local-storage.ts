// storage-mocks.ts
// ---------------------------------------------------------------------------
// Unified mocks for localStorage, sessionStorage and IndexedDB in Vitest
// ---------------------------------------------------------------------------
