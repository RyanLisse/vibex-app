/**
 * E2E Test Framework for VibeKit Components
 *
 * This framework provides comprehensive utilities for testing React components
 * with real user interactions, focusing on behavior rather than implementation.
 */
