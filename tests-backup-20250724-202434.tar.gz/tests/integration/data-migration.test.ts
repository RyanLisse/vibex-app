/**
 * Data Migration Tests
 *
 * Tests to verify data migration from Zustand stores to database works correctly
 */
