/**
 * Bun Mock Utilities
 * Standardized mock utilities for Bun test runner
 * Replaces Vitest mocked() patterns with proper Bun equivalents
 */
